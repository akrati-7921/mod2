package com.cg.module2.jdbc.service;

import com.cg.module2.jdbc.bean.Employee;

public interface IEmployeeService {

	public void addEmployee(int id,String name,String des,double sal);
	public void displayEmployee(String ins_sch);
	public void deleteEmployee(int id);
	public void sortEmployee();
}
