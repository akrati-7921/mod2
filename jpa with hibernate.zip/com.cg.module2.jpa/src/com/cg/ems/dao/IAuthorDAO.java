package com.cg.ems.dao;

import java.util.ArrayList;

import com.cg.ems.bean.Author;

public interface IAuthorDAO {

	public Author addAuth(Author auth);
	public ArrayList<Author> fetchAllAuth();
	public Author deleteAuth(int authId);
	public Author getAuthbyAuthid(int authId);
	public Author updateAuth(int authId, String newFName, String newMName, String newLName, String newPNo);
}
