package com.cg.ems.dao;

import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.TypedQuery;

import com.cg.ems.bean.Author;

import com.cg.ems.util.JPAUtil;

public class AuthorDAOImpl implements IAuthorDAO{

	EntityManager em=null;
	EntityTransaction entityTran=null;
	
	public AuthorDAOImpl() {
		// TODO Auto-generated constructor stub
		
		em=JPAUtil.getEntityManager();
		entityTran=em.getTransaction();
	}
	
	@Override
	public Author addAuth(Author auth) {
		// TODO Auto-generated method stub
		
		entityTran.begin();
		em.persist(auth);
		entityTran.commit();
		return auth;
	}

	@Override
	public ArrayList<Author> fetchAllAuth() {
		// TODO Auto-generated method stub
		
		String selAllQry="SELECT auth from Author auth";
		TypedQuery<Author> tq=em.createQuery(selAllQry,Author.class);
		ArrayList<Author> authList=(ArrayList)tq.getResultList();
		return authList;
	}

	@Override
	public Author deleteAuth(int authId) {
		// TODO Auto-generated method stub
		
		Author a1=em.find(Author.class,authId);
		entityTran.begin();
		em.remove(a1);
		entityTran.commit();
		return a1;
	}

	@Override
	public Author getAuthbyAuthid(int authId) {
		// TODO Auto-generated method stub
		
		Author aa=em.find(Author.class,authId);
		return aa;
	}

	@Override
	public Author updateAuth(int authId, String newFName, String newMName, String newLName, String newPNo) {
		// TODO Auto-generated method stub
		
		Author aa=em.find(Author.class,authId);
		aa.setAuthorId(authId);
		aa.setFirstName(newFName);
		aa.setMiddleName(newMName);
		aa.setLastName(newLName);
		aa.setPhoneNo(newPNo);
		entityTran.begin();
		em.merge(aa);
		entityTran.commit();
		return aa;
	}


}
