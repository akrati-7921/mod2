package com.cg.ems.ui;

import java.util.ArrayList;
import java.util.Scanner;
import com.cg.ems.bean.Author;
import com.cg.ems.service.AuthorServiceImpl;
import com.cg.ems.service.IAuthorService;



public class AuthorUI {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		IAuthorService authSer=new AuthorServiceImpl();
		Scanner scan=new Scanner(System.in);
		while(true)
		{
			System.out.println("1.Add Auhtor\n2.Fetch All Author\n3.Delete Author\n4."
					+ "Get Auhtor by Id\n5.Update Author details\n6.Exit\nEnter your choice");
			int choice=scan.nextInt();
			switch(choice)
			{
			case 1:
				System.out.println("Enter the id");
				int id=scan.nextInt();
				System.out.println("Enter first name");
				scan.nextLine();
				String firstnm=scan.nextLine();
				System.out.println("Enter middle name");
				String middlenm=scan.nextLine();
				System.out.println("Enter last name");
				String lastnm=scan.nextLine();
				System.out.println("Enter phone number");
				String phoneno=scan.nextLine();
				Author a1=new Author(id,firstnm,middlenm,lastnm,phoneno);
				Author aa1=authSer.addAuth(a1);
				System.out.println("Author details:\n"+aa1);
				break;
			case 2:
				System.out.println("Fetch All Records...");
				ArrayList<Author> aList=authSer.fetchAllAuth();
				for(Author aa:aList)
				{
					System.out.println(aa.getAuthorId()+"\t"+aa.getFirstName()+"\t"+aa.getMiddleName()
					+"\t"+aa.getLastName()+"\t"+aa.getPhoneNo());
				}
				break;
			case 3:
				System.out.println("Enter the id want to delete");
				int delId=scan.nextInt();
				System.out.println("Deleted...");
				Author deletedEmp=authSer.deleteAuth(delId);
				System.out.println(deletedEmp);
				break;
			case 4:
				System.out.println("Enter the id want to fetch details");
				int fetchId=scan.nextInt();
				System.out.println("Details are...");
				Author fetch=authSer.getAuthbyAuthid(fetchId);
				System.out.println(fetch);
				break;
			case 5:
				System.out.println("Enter the id want to update details");
				int updateId=scan.nextInt();
				System.out.println("Enter first name");
				scan.nextLine();
				String fnm=scan.nextLine();
				System.out.println("Enter middle name");
				String mnm=scan.nextLine();
				System.out.println("Enter last name");
				String lnm=scan.nextLine();
				System.out.println("Enter phone number");
				String pno=scan.nextLine();
				System.out.println("Updated...");
				Author updateA=authSer.updateAuth(updateId,fnm,mnm,lnm,pno);
				System.out.println(updateA);
				break;
			case 6:
				System.exit(0);
				break;
			default:
				System.out.println("wrong choice");
				break;
			}
		}
	}
}
