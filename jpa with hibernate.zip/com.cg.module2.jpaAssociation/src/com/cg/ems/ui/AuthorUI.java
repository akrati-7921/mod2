package com.cg.ems.ui;

import java.util.ArrayList;
import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;

import com.cg.ems.bean.Author;
import com.cg.ems.bean.Book;
import com.cg.ems.service.AuthorServiceImpl;
import com.cg.ems.service.IAuthorService;
import com.cg.ems.util.JPAUtil;



public class AuthorUI {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		IAuthorService sevice=new AuthorServiceImpl();
		EntityManager em=JPAUtil.getEntityManager();
		EntityTransaction et=em.getTransaction();
		
		Author a1=new Author();
		Author a2=new Author();
		Author a3=new Author();
		Author a4=new Author();
		Author a5=new Author();
		
		Book b1=new Book();
		Book b2=new Book();
		Book b3=new Book();
		Book b4=new Book();
		
		a1.setAuthId(111);
		a1.setName("Sona Charaipotra");
		a2.setAuthId(222);
		a2.setName("Dhonielle Clayton");
		a3.setAuthId(333);
		a3.setName("Stephen King");
		a4.setAuthId(444);
		a4.setName("Peter Straub");
		a5.setAuthId(555);
		a5.setName("John Green");
		
		b1.setBookId(100);
		b1.setTitle("Tiny Pretty Things");
		b1.setPrice(800.0F);
		b2.setBookId(200);
		b2.setTitle("The Talisman");
		b2.setPrice(950.0F);
		b3.setBookId(300);
		b3.setTitle("IT");
		b3.setPrice(500.0f);
		b4.setBookId(400);
		b4.setTitle("The Fault in our Stars");
		b4.setPrice(650.0F);
		
		a1.getBookSet().add(b1);
		a2.getBookSet().add(b1);
		a3.getBookSet().add(b2);
		a4.getBookSet().add(b2);
		a3.getBookSet().add(b3);
		a5.getBookSet().add(b4);
		
		b1.getAuthorSet().add(a1);

		b1.getAuthorSet().add(a2);
		b1.getAuthorSet().add(a1);
		b2.getAuthorSet().add(a3);
		b2.getAuthorSet().add(a4);
		b3.getAuthorSet().add(a3);
		b4.getAuthorSet().add(a5);
		
		et.begin();
		em.persist(a1);
		em.persist(a2);
		em.persist(a3);
		em.persist(a4);
		em.persist(a5);
		em.persist(b1);
		em.persist(b2);
		em.persist(b3);
		em.persist(b4);
		et.commit();
		
		Scanner scan=new Scanner(System.in);
		while(true)
		{
			System.out.println("1.Display books\n2.Display books by given Author\n3."
					+ "Display books given by price\n4.Display author name given by book id"
					+ "\n5.Exit\nEnter your choice");
			int choice=scan.nextInt();
			switch(choice)
			{
			case 1:
				ArrayList<Book> book1=sevice.getDetails();
				System.out.println(book1);
				break;
			case 2:
				ArrayList<Book> book2=sevice.getDetailsByAuthor("Sona Charaipotra");
				System.out.println(book2);
				break;
			case 3:
				ArrayList<Book> book3=sevice.getDetailsByPrice(500.0F,1000.0F);
				System.out.println(book3);
				break;
			case 4:
				ArrayList<Author> author=sevice.getDetailsByBookId(100);
				System.out.println(author);
			case 5:
				System.exit(0);
				break;
			default:
				System.out.println("wrong choice");
				break;
			}
		}
	}
}
