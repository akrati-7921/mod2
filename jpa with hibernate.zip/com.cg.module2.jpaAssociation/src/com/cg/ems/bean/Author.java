package com.cg.ems.bean;

import java.util.HashSet;
import java.util.Set;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;


@Entity
@Table(name="auth")
public class Author {

	@Id
	@Column(name="auth_id",length=20)
	private int authId;
	@Column(name="auth_name",length=20)
	private String Name;
	
	@ManyToMany(cascade=CascadeType.ALL)
	@JoinTable(name="book_author",joinColumns= {
			@JoinColumn(name="auth_id")},inverseJoinColumns= {@JoinColumn(name="book_id")})
	
	Set<Book> bookSet=new HashSet<Book>();
	
	public Author() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Author(int authId, String name, Set<Book> bookSet) {
		super();
		this.authId = authId;
		Name = name;
		this.bookSet = bookSet;
	}

	public int getAuthId() {
		return authId;
	}

	public void setAuthId(int authId) {
		this.authId = authId;
	}

	public String getName() {
		return Name;
	}

	public void setName(String name) {
		Name = name;
	}
	
	public Set<Book> getBookSet() {
		return bookSet;
	}

	public void setBookSet(Set<Book> bookSet) {
		this.bookSet = bookSet;
	}

	@Override
	public String toString() {
		return "Author [authId=" + authId + ", Name=" + Name +  "]";
	}
	
}
