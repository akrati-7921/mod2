package com.cg.ems.bean;

import java.util.HashSet;
import java.util.Set;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Table;


@Entity
@Table(name="book")
public class Book {
	
	@Id
	@Column(name="book_id",length=20)
	private int bookId;
	@Column(name="book_title",length=40)
	private String title;
	@Column(name="book_price",length=20)
	private float price;
	
	@ManyToMany(mappedBy="bookSet")
	private Set<Author> authorSet=new HashSet<Author>();

	
	public Book() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public Book(int bookId, String title, float price, Set<Author> authorSet) {
		super();
		this.bookId = bookId;
		this.title = title;
		this.price = price;
		this.authorSet = authorSet;
	}

	public int getBookId() {
		return bookId;
	}

	public void setBookId(int bookId) {
		this.bookId = bookId;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public float getPrice() {
		return price;
	}

	public void setPrice(float price) {
		this.price = price;
	}

	public Set<Author> getAuthorSet() {
		return authorSet;
	}

	public void setAuthorSet(Set<Author> authorSet) {
		this.authorSet = authorSet;
	}

	@Override
	public String toString() {
		return "Book [bookId=" + bookId + ", title=" + title + ", price=" + price +  "]";
	}
	
}
