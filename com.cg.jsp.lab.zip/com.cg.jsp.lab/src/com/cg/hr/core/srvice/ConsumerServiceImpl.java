package com.cg.hr.core.srvice;

import java.util.ArrayList;

import com.cg.hr.core.bean.Consumer;
import com.cg.hr.core.dao.ConsumerDao;
import com.cg.hr.core.dao.ConsumerDaoImpl;
import com.cg.hr.core.exception.ConsumerException;

public class ConsumerServiceImpl implements ConsumerService{

	ConsumerDao cons=null;
	public ConsumerServiceImpl() throws ConsumerException
	{
		cons=new ConsumerDaoImpl();
	}
	@Override
	public ArrayList<Consumer> fetchAllConsumer() throws ConsumerException {
		// TODO Auto-generated method stub
		return cons.fetchAllConsumer();
	}

	@Override
	public Consumer getConsumerbyCid(int cId) throws ConsumerException {
		// TODO Auto-generated method stub
		return cons.getConsumerbyCid(cId);
	}

	
}
