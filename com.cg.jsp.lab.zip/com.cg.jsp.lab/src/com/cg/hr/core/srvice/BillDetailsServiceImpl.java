package com.cg.hr.core.srvice;

import java.util.ArrayList;

import com.cg.hr.core.bean.BillDetails;
import com.cg.hr.core.dao.BillDetailsDao;
import com.cg.hr.core.dao.BillDetailsDaoImpl;
import com.cg.hr.core.exception.BillDetailsException;
import com.cg.hr.core.exception.ConsumerException;

public class BillDetailsServiceImpl implements BillDetailsService{

	BillDetailsDao bill=null;
	public BillDetailsServiceImpl() throws ConsumerException {
		// TODO Auto-generated constructor stub
		bill=new BillDetailsDaoImpl();
	}
	@Override
	public ArrayList<BillDetails> fetchAllBill(int conId) throws BillDetailsException {
		// TODO Auto-generated method stub
		return bill.fetchAllBill(conId);
	}
	@Override
	public BillDetails generateBill(int conId, float lastBillGenerated, float currentBillGenerated)
			throws BillDetailsException {
		// TODO Auto-generated method stub
		return bill.generateBill(conId, lastBillGenerated, currentBillGenerated);
	}

}
