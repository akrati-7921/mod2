package com.cg.hr.core.srvice;

import java.util.ArrayList;

import com.cg.hr.core.bean.BillDetails;
import com.cg.hr.core.exception.BillDetailsException;

public interface BillDetailsService {

	public ArrayList<BillDetails> fetchAllBill(int conId) throws BillDetailsException;
	public BillDetails generateBill(int conId,float lastBillGenerated,float currentBillGenerated) throws BillDetailsException;

}
