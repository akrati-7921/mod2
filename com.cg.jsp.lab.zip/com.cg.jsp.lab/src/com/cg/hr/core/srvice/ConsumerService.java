package com.cg.hr.core.srvice;

import java.util.ArrayList;
import com.cg.hr.core.bean.Consumer;
import com.cg.hr.core.exception.ConsumerException;


public interface ConsumerService {

	public ArrayList<Consumer> fetchAllConsumer() throws ConsumerException;
	public Consumer getConsumerbyCid(int cId) throws ConsumerException;
}
