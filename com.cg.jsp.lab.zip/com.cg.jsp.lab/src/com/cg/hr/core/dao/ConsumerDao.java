package com.cg.hr.core.dao;

import java.util.ArrayList;
import com.cg.hr.core.bean.Consumer;
import com.cg.hr.core.exception.ConsumerException;

public interface ConsumerDao {
	
	public ArrayList<Consumer> fetchAllConsumer() throws ConsumerException;
	public Consumer getConsumerbyCid(int cId) throws ConsumerException;
	
}
