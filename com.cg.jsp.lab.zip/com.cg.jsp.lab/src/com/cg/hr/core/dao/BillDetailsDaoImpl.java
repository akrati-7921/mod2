package com.cg.hr.core.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Calendar;

import com.cg.hr.core.bean.BillDetails;
import com.cg.hr.core.exception.BillDetailsException;
import com.cg.hr.core.exception.ConsumerException;
import com.cg.hr.core.util.JDBCUtil;

public class BillDetailsDaoImpl implements BillDetailsDao{

	private Connection connect;
	final int fixedCharge=100;
	
	public BillDetailsDaoImpl() throws ConsumerException {
		// TODO Auto-generated constructor stub
		JDBCUtil util=new JDBCUtil();
		connect=util.getConnect();
	}
	
	@Override
	public ArrayList<BillDetails> fetchAllBill(int conId) throws BillDetailsException {
		// TODO Auto-generated method stub
		
		PreparedStatement pstmt =null;
		ResultSet rs=null;
		BillDetails bill=null;
		ArrayList<BillDetails> billList=new ArrayList<BillDetails>();
		try {
			pstmt =connect.prepareStatement("select * from BillDetails where con_id=?");
			pstmt.setInt(1,conId);
			rs=pstmt.executeQuery();
			
			while(rs.next())
			{
				int bill_num= rs.getInt("bill_num");
				float cur_reading=rs.getFloat("cur_reading");
				float unitConsumed=rs.getFloat("unitconsumed");
				float netAmount=rs.getFloat("netamount");
				Date bill_date=rs.getDate("bill_date");
				bill=new BillDetails(bill_num,cur_reading,unitConsumed,netAmount,bill_date);				
				billList.add(bill);
			}
			return billList;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			throw new BillDetailsException("Something wrong in fetchAllBill()",e);
		}
		finally
		{
			try {
				if(rs!= null)
				{
					rs.close();
				}
				if(pstmt!=null)
				{
					pstmt.close();
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	@Override
	protected void finalize() throws Throwable {
		// TODO Auto-generated method stub
		if(connect!=null)
		{
			connect.close();
		}
		super.finalize();
	}

	@Override
	public BillDetails generateBill(int conId, float lastBillGenerated, float currentBillGenerated)
			throws BillDetailsException {
		// TODO Auto-generated method stub
		
		float units=currentBillGenerated-lastBillGenerated;
		float amount=(float) (units*1.15+fixedCharge);
		Calendar calendar = Calendar.getInstance();
		java.util.Date currentDate = calendar.getTime();
		java.sql.Date date = new java.sql.Date(currentDate.getTime());
		
		String insertQry="insert into billdetails(con_id,cur_reading,unitconsumed,netamount,bill_date) values(?,?,?,?,?)";
		
		PreparedStatement pstmt=null;
		BillDetails bill=null;
		
		try {
			connect.setAutoCommit(false);
			pstmt=connect.prepareStatement(insertQry);
			pstmt.setInt(1,conId);
			pstmt.setFloat(2,currentBillGenerated);
			pstmt.setFloat(3,units);
			pstmt.setFloat(4,amount);
			pstmt.setDate(5,date);
			pstmt.executeQuery();
			bill=new BillDetails(currentBillGenerated,units,amount,date);
			return bill;
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			throw new BillDetailsException("Error Occured:\nNo bill details for consumer number"+Integer.toString(conId),e);
		}	
		finally
		{
			try {
				connect.setAutoCommit(true);
				if(pstmt!=null)
				{
					pstmt.close();
				}			
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	

}
