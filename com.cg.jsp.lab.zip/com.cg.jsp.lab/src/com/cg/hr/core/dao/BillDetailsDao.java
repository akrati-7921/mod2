package com.cg.hr.core.dao;

import java.util.ArrayList;

import com.cg.hr.core.bean.BillDetails;
import com.cg.hr.core.exception.BillDetailsException;

public interface BillDetailsDao {

	public ArrayList<BillDetails> fetchAllBill(int conId) throws BillDetailsException;
	public BillDetails generateBill(int conId,float lastBillGenerated,float currentBillGenerated) throws BillDetailsException;
}
