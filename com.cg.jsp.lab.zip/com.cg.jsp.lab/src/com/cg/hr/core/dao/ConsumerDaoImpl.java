package com.cg.hr.core.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import com.cg.hr.core.bean.Consumer;
import com.cg.hr.core.exception.ConsumerException;
import com.cg.hr.core.util.JDBCUtil;


public class ConsumerDaoImpl implements ConsumerDao{

	private Connection connect;
	
	public ConsumerDaoImpl() throws ConsumerException
	{
		JDBCUtil util=new JDBCUtil();
		connect=util.getConnect();
		
	}
	
	@Override
	public ArrayList<Consumer> fetchAllConsumer() throws ConsumerException{
		// TODO Auto-generated method stub
		Statement stmt =null;
		ResultSet rs=null;
		ArrayList<Consumer> conList=new ArrayList<Consumer>();
		try {
			stmt =connect.createStatement();
			rs=stmt.executeQuery("select * from consumer");
			
			while(rs.next())
			{
				int consumer_num= rs.getInt("con_id");
				String consumer_name=rs.getString("con_name");
				String address=rs.getString("address");
				Consumer con=new Consumer(consumer_num,consumer_name,address);
				conList.add(con);
			}
			return conList;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			throw new ConsumerException("Something wrong in fetchAllEmp()",e);
		}
		finally
		{
			try {
				if(rs!= null)
				{
					rs.close();
				}
				if(stmt!=null)
				{
					stmt.close();
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	
	@Override
	protected void finalize() throws Throwable {
		// TODO Auto-generated method stub
		if(connect!=null)
		{
			connect.close();
		}
		super.finalize();
	}

	@Override
	public Consumer getConsumerbyCid(int cId) throws ConsumerException {
		// TODO Auto-generated method stub
		PreparedStatement pstmt =null;
		ResultSet rs=null;
		Consumer con=null;
		try {
			pstmt =connect.prepareStatement("Select * from consumer where con_id=?");
			pstmt.setInt(1,cId);
			rs=pstmt.executeQuery();
			while(rs.next())
			{
				int c_id= rs.getInt("con_id");
				String c_name=rs.getString("con_name");
				String c_address=rs.getString("address");
				con=new Consumer(c_id,c_name,c_address);
			}
			return con;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			throw new ConsumerException("Something wrong in fetchAllEmp()",e);
		}
		finally
		{
			try {
				if(rs!= null)
				{
					rs.close();
				}
				if(pstmt!=null)
				{
					pstmt.close();
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
}
