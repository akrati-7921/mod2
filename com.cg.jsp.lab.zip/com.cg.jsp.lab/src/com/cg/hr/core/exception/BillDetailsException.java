package com.cg.hr.core.exception;

public class BillDetailsException extends Exception{

	private static final long serialVersionUID = 1L;

	String exception=null;
	
	public BillDetailsException() {
		// TODO Auto-generated constructor stub
		super();
	}
	
	public BillDetailsException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public BillDetailsException(String message) {
		super(message);
		this.exception=message;
	}

	
	
}
