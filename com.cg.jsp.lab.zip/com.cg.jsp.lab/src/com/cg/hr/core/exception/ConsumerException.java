package com.cg.hr.core.exception;

public class ConsumerException extends Exception{

	private static final long serialVersionUID = 1L;

	public ConsumerException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public ConsumerException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
	

}
