package com.cg.hr.core.listener;

import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebListener;
import com.cg.hr.core.exception.ConsumerException;
import com.cg.hr.core.srvice.ConsumerService;
import com.cg.hr.core.srvice.ConsumerServiceImpl;


@WebListener
public class CreateServiceResources implements ServletContextListener {

	private ConsumerService service;
	
    public void contextDestroyed(ServletContextEvent arg0)  { 
         // TODO Auto-generated method stub
    	service=null;
    }

	
    public void contextInitialized(ServletContextEvent arg0)  { 
         // TODO Auto-generated method stub
    	try {
			service=new ConsumerServiceImpl();
			ServletContext ctx=arg0.getServletContext();
			ctx.setAttribute("services",service);
		} catch (ConsumerException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	
    }
	
}
