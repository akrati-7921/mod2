package com.cg.hr.web;

import java.io.IOException;
import java.util.ArrayList;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.hr.core.bean.BillDetails;
import com.cg.hr.core.bean.Consumer;
import com.cg.hr.core.exception.BillDetailsException;
import com.cg.hr.core.exception.ConsumerException;
import com.cg.hr.core.srvice.BillDetailsService;
import com.cg.hr.core.srvice.BillDetailsServiceImpl;
import com.cg.hr.core.srvice.ConsumerService;
import com.cg.hr.core.srvice.ConsumerServiceImpl;


@WebServlet("*.hr")
public class FrontControllerHR extends HttpServlet {
	
	private static final long serialVersionUID = 1L;
	private ConsumerService service;
	private BillDetailsService billService;
	
	@Override
	public void init() throws ServletException {
		// TODO Auto-generated method stub
		super.init();
		try {
			service=new ConsumerServiceImpl();
			billService=new BillDetailsServiceImpl();
		} catch (ConsumerException e) {
			// TODO Auto-generated catch block
			throw new ServletException("Missed service refernce.",e);
		}
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		ServletContext ctx=super.getServletContext();
		ConsumerService service=(ConsumerService) ctx.getAttribute("services");
		String url=request.getRequestURI();
		String command=getCommand(url);
		RequestDispatcher dispatcher=null;
		String jspName=null;
		String preFix="/WEB-INF/pages/";
		String postFix=".jsp";
		
		try {
			switch(command) {
				case "*" :
				case "index":{
					jspName="index";
					break;
				}
				case "ShowConsumer" : {
					ArrayList<Consumer> conList=service.fetchAllConsumer();
					request.setAttribute("conList",conList);
					jspName="Show_ConsumerList";
					break;
				}
				case "SearchConsumer" : {
					jspName="Search_Consumer";
					break;
				}
				case "ShowConsumerById" : {
					HttpSession session= request.getSession(true);
					String strConId=request.getParameter("cid");
					int conId =Integer.parseInt(strConId);
					Consumer con=service.getConsumerbyCid(conId);
					request.setAttribute("conNum",con.getConsumer_num());
					request.setAttribute("conName",con.getConsumer_name());
					request.setAttribute("conAddress",con.getAddress());
					jspName="ShowConsumer";
					break;
				}
				case "BillDetails" : {
					String strConId=request.getParameter("id");
					int conId =Integer.parseInt(strConId);
					request.setAttribute("conNum",conId);
					ArrayList<BillDetails> billList=billService.fetchAllBill(conId);
					request.setAttribute("billList",billList);
					jspName="BillDetails";
					break;
				}
				case "GenerateBill":{
					jspName="GenerateBill";
					break;
				}
				case "Billinformation":{
					String strConId=request.getParameter("consumerId");
					int consumerId =Integer.parseInt(strConId);
					String lastBill=request.getParameter("lastBill");
					float lastBillGenerated=Float.parseFloat(lastBill);
					String currentBill=request.getParameter("currentBill");
					float currentBillGenerated=Float.parseFloat(currentBill);
					Consumer con=service.getConsumerbyCid(consumerId);
					request.setAttribute("name",con.getConsumer_name());
					request.setAttribute("id",consumerId);
					BillDetails bill=billService.generateBill(consumerId, lastBillGenerated, currentBillGenerated);
					request.setAttribute("unit",bill.getUnitConsumed());
					request.setAttribute("amount",bill.getNetAmount());
					jspName="Billinformation";
					break;
				}
				case "Logout" : {
					HttpSession session= request.getSession(false);
					session.invalidate();
					jspName="Thanks";
					break;
				}
			}
		} catch (ConsumerException | BillDetailsException e) {
			// TODO Auto-generated catch block
			BillDetailsException exception=new BillDetailsException();
			request.setAttribute("message",exception);
			jspName="Error";
			e.printStackTrace();
		}
		dispatcher=request.getRequestDispatcher(preFix+jspName+postFix);
		dispatcher.forward(request, response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request,response);
	}
	
	private String getCommand(String url){
		
		int idxSlash= url.lastIndexOf("/");
		int idxDot=url.lastIndexOf(".");
		if(idxDot<0)
		{
			return "index";
		}
		else
		{
			return url.substring(idxSlash+1, idxDot);
		}
	}

}
