var msg;
msg="<p><code>The actual script is in external script file called common.js</code></p>";

function addNos(headVar,bodyVar)
{
	document.write(msg);
	document.write("The sum of the variable headVar and bodyVar is "+ (headVar+bodyVar)+"<hr>");
}